package org.ahmed.services;

import java.util.List;

import org.ahmed.entites.ligne_liv;
import org.ahmed.entites.societe;
import org.ahmed.metier.LigneLiv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ligneLivRest {

	@Autowired
	private LigneLiv metier ;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/ligneliv",method=RequestMethod.POST)
	public ligne_liv save(@RequestBody ligne_liv c) {
		return metier.save(c) ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/ligneliv",method=RequestMethod.GET)
	public List<ligne_liv> listClient(){
		return metier.listLigne() ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/ligneliv/{id}")
	public void supprimer(@PathVariable Long id) {
		metier.Supprimer(id) ;
	}
	//la methode mis a jour
    @CrossOrigin(origins = "http://localhost:4200")
	@PutMapping("/ligneliv/{id}")
	public void Ajour(@PathVariable("id") long id, @RequestBody ligne_liv a ) {
		
		metier.Ajour(id, a) ;
	}
}
