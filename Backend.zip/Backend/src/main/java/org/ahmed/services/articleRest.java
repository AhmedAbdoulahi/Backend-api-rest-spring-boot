package org.ahmed.services;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.articleRepository;
import org.ahmed.entites.article;
import org.ahmed.entites.societe;
import org.ahmed.metier.articleMetier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class articleRest {
	@Autowired
	private articleMetier metier ;
	private articleRepository rep ;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/articles",method=RequestMethod.POST)
	public article save(@RequestBody article c) {
		return metier.save(c) ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/articles",method=RequestMethod.GET)
	public List<article> listClient(){
		return metier.listArticle() ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/articles/{id}")
	public void supprimer(@PathVariable Long id) {
		metier.Supprimer(id) ;
	}
	
	//la methode mis a jour
		@PutMapping("/article/{id}")
		public void Ajour(@PathVariable("id") long id, @RequestBody article a ) {
			metier.Ajour(id, a) ;
		}
}
