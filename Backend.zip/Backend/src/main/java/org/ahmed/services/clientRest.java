package org.ahmed.services;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.articleRepository;
import org.ahmed.dao.clientRepository;
import org.ahmed.entites.article;
import org.ahmed.entites.client;
import org.ahmed.entites.ligne_liv;
import org.ahmed.metier.clientMetier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class clientRest {

	@Autowired
	private clientMetier metier ;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/clients",method=RequestMethod.POST)
	public client save(@RequestBody client c) {
		return metier.save(c) ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/clients",method=RequestMethod.GET)
	public List<client> listClient(){
		return metier.listClient() ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/clients/{id}",method=RequestMethod.GET)
	public void supprimer(@PathVariable Long id){
		metier.Supprimer(id) ;
	}
	//la methode mis a jour
	@PutMapping("/client/{id}")
	public void Ajour(@PathVariable Long id, @RequestBody client a ) {
		metier.Ajour(id, a) ;
		
		
	}
}
