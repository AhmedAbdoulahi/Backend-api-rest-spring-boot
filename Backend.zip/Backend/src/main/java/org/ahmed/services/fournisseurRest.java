package org.ahmed.services;

import java.util.List;

import org.ahmed.entites.client;
import org.ahmed.entites.commande;
import org.ahmed.entites.fournisseur;
import org.ahmed.metier.fournisseurMetier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class fournisseurRest {

	@Autowired
	private fournisseurMetier metier ;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/fournisseurs",method=RequestMethod.POST)
	public fournisseur save(@RequestBody fournisseur c) {
		return metier.save(c) ;
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/fournisseurs",method=RequestMethod.GET)
	public List<fournisseur> listClient(){
		return metier.listFournisseur() ;
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/fournisseurs/{id}")
	public void supprimer(@PathVariable Long id) {
		metier.Supprimer(id) ;
	}
	
	//la methode mis a jour
		@PutMapping("/fournisseur/{id}")
		public void Ajour(@PathVariable("id") long id, @RequestBody fournisseur a ) {
				
			metier.Ajour(id, a) ;
		}
}
