package org.ahmed.services;

import java.util.List;

import org.ahmed.entites.ligne_cmd;
import org.ahmed.entites.societe;
import org.ahmed.metier.ligne_Cmd;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class lignCmdRest {
	
	@Autowired
	private ligne_Cmd metier ;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/lignecmd",method=RequestMethod.POST)
	public ligne_cmd save(@RequestBody ligne_cmd c) {
		return metier.save(c) ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/lignecmd",method=RequestMethod.GET)
	public List<ligne_cmd> listClient(){
		return metier.listLigne() ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/lignecmd/{id}")
	public void supprimer(@PathVariable Long id) {
		metier.Supprimer(id) ;
	}
	//la methode mis a jour
    @CrossOrigin(origins = "http://localhost:4200")
	@PutMapping("/lignecmd/{id}")
	public void Ajour(@PathVariable("id") long id, @RequestBody ligne_cmd a ) {
		
		metier.Ajour(id, a) ;
	}
}
