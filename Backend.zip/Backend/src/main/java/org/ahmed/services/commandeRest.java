package org.ahmed.services;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.commandeRepository;
import org.ahmed.entites.client;
import org.ahmed.entites.commande;
import org.ahmed.metier.commandeMetier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class commandeRest {
	
	@Autowired
	private commandeMetier metier ;
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value="/commandes")
	public commande save(@RequestBody commande c) {
		return metier.save(c) ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value="/commandes")
	public List<commande> listCommande(){
		return metier.listCommande() ;
	}
	//methode pour la suppression
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/commandes/{id}")
	public void supprimer(@PathVariable Long id) {
		metier.Supprimer(id) ;
	}
	
	//la methode mis a jour
	    @CrossOrigin(origins = "http://localhost:4200")
		@PutMapping("/commande/{id}")
		public void Ajour(@PathVariable("id") long id, @RequestBody commande a ) {
			
			metier.Ajour(id, a) ;
		}
	
}
