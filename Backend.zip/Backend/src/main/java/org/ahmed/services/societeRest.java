package org.ahmed.services;

import java.util.List;

import org.ahmed.entites.commande;
import org.ahmed.entites.livraison;
import org.ahmed.entites.societe;
import org.ahmed.metier.societeMetier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class societeRest {
	
	@Autowired
	private societeMetier metier ;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/societes",method=RequestMethod.POST)
	public societe save(@RequestBody societe c) {
		return metier.save(c) ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value="/societes",method=RequestMethod.GET)
	public List<societe> listClient(){
		return metier.listSociete() ;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value="/societes/{id}")
	public void supprimer(@PathVariable Long id) {
		metier.Supprimer(id) ;
	}
	//la methode mis a jour
    @CrossOrigin(origins = "http://localhost:4200")
	@PutMapping("/societe/{id}")
	public void Ajour(@PathVariable("id") long id, @RequestBody societe a ) {
		
		metier.Ajour(id, a) ;
	}
}
