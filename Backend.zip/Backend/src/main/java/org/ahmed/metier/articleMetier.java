package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.article;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

public interface articleMetier {
	public article save(article a); 
	public List<article> listArticle(); 
	public void Supprimer(Long a) ;
	public article Ajour(Long id, article a ) ;
}
