package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.articleRepository;
import org.ahmed.entites.article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
@Service
public class articleMetierImpl implements articleMetier {

	@Autowired
	private articleRepository repository ;
	
	@Override
	public article save(article a) {
		// TODO Auto-generated method stub
		return repository.save(a) ;
	}

	@Override
	public List<article> listArticle() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public article Ajour(Long id,  article a ) {
		
		Optional<article> c = repository.findById(id) ;
		if(c.isPresent()) {
			article art = c.get() ;
			art.setNom_art(a.getNom_art()) ;
			art.setPu(a.getPu()) ;
			art.setQte_stock(a.getQte_stock()) ;
			return repository.save(art) ;
		}
		else {
			return null ;
		}
	}



}
