package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.ligne_liv;
import org.ahmed.entites.societe;

public interface LigneLiv {
	public ligne_liv save(ligne_liv c); 
	public List<ligne_liv> listLigne(); 
	public void Supprimer(Long c) ;
	public ligne_liv Ajour(Long id,  ligne_liv a ) ;
}
