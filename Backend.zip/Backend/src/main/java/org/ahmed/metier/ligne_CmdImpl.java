package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.ligne_cmdRepository;
import org.ahmed.entites.ligne_cmd;
import org.ahmed.entites.societe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class ligne_CmdImpl implements ligne_Cmd {
	@Autowired
	private ligne_cmdRepository repository ;
	@Override
	public ligne_cmd save(ligne_cmd c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<ligne_cmd> listLigne() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public ligne_cmd Ajour(Long id, ligne_cmd a) {
		// TODO Auto-generated method stub
		Optional<ligne_cmd> c = repository.findById(id) ;
		if(c.isPresent()) {
			ligne_cmd cmd = c.get() ;
			cmd.setId(a.getId());
			cmd.setQte(a.getQte());
			cmd.setArticle(a.getArticle());
			cmd.setCommande(a.getCommande());
			return repository.save(cmd) ;
		}
		else {
			return null ;
		}
	}

}
