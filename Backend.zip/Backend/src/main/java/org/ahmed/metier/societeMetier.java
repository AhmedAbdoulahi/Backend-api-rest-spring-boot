package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.commande;
import org.ahmed.entites.societe;

public interface societeMetier {
	public societe save(societe c); 
	public List<societe> listSociete(); 
	public void Supprimer(Long c) ;
	public societe Ajour(Long id,  societe a ) ;
}
