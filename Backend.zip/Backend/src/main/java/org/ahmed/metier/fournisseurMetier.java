package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.commande;
import org.ahmed.entites.fournisseur;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

public interface fournisseurMetier {
	public fournisseur save(fournisseur c); 
	public List<fournisseur> listFournisseur(); 
	public void Supprimer(Long c) ;
	public fournisseur Ajour(Long id, fournisseur a );
}
