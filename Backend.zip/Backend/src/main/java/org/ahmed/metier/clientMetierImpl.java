package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.clientRepository;
import org.ahmed.entites.client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class clientMetierImpl implements clientMetier {
	
	@Autowired
	private clientRepository repository ;

	@Override
	public client save(client c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<client> listClient() {
		// TODO Auto-generated method stub
		return repository.findAll() ;
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		//client cli = repository.findById(c).get();
		repository.deleteById(c);
	}

	@Override
	public client Ajour(Long id, @RequestBody client a ) {
		
		Optional<client> c = repository.findById(id) ;
		if(c.isPresent()) {
			client cli = c.get() ;
			cli.setNom_cli(a.getNom_cli()) ;
			cli.setPre_cli(a.getPre_cli()) ;
			cli.setTel_cli(a.getTel_cli()) ;
			cli.setAdr_cli(a.getAdr_cli()) ;
			cli.setVille_cli(a.getVille_cli()) ;
			return repository.save(cli) ;
		}
		else {
			return null ;
		}
	}

}
