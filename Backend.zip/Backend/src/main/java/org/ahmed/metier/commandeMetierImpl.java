package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.clientRepository;
import org.ahmed.dao.commandeRepository;
import org.ahmed.entites.commande;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class commandeMetierImpl implements commandeMetier {

	@Autowired
	private commandeRepository repository ;
	
	@Override
	public commande save(commande c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<commande> listCommande() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public commande Ajour(Long id, commande a ) {
		
		Optional<commande> c = repository.findById(id) ;
		if(c.isPresent()) {
			commande cmd = c.get() ;
			cmd.setDateCmd(a.getDateCmd()) ;
			cmd.setCli(a.getCli()) ;
			cmd.setLig_cmd(a.getLig_cmd()) ;
			return repository.save(cmd) ;
		}
		else {
			return null ;
		}
	}

}
