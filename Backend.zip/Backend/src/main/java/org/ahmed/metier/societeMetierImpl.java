package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.societeRepository;
import org.ahmed.entites.commande;
import org.ahmed.entites.societe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class societeMetierImpl implements societeMetier {

	@Autowired
	private societeRepository repository ;
	@Override
	public societe save(societe c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<societe> listSociete() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public societe Ajour(Long id, societe a) {
		// TODO Auto-generated method stub
		Optional<societe> c = repository.findById(id) ;
		if(c.isPresent()) {
			societe s = c.get() ;
			s.setNom_ste(a.getNom_ste());
			s.setFour(a.getFour());
			s.setFax(a.getFax());
			s.setTel(a.getTel());
			s.setVille(a.getVille());
			return repository.save(s) ;
		}
		else {
			return null ;
		}
	}
	
}
