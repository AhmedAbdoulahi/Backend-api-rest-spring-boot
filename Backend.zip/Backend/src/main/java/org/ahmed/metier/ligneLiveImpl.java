package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.ligne_livRepository;
import org.ahmed.entites.ligne_liv;
import org.ahmed.entites.societe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class ligneLiveImpl implements LigneLiv {

	@Autowired
	private ligne_livRepository repository ;
	
	@Override
	public ligne_liv save(ligne_liv c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<ligne_liv> listLigne() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public ligne_liv Ajour(Long id, ligne_liv a) {
		// TODO Auto-generated method stub
		Optional<ligne_liv> c = repository.findById(id) ;
		if(c.isPresent()) {
			ligne_liv l = c.get() ;
			l.setCle(a.getCle());
			l.setArticle(a.getArticle());
			l.setCod(a.getCod());
			l.setQte_liv(a.getQte_liv());
			return repository.save(l) ;
		}
		else {
			return null ;
		}
	}

}
