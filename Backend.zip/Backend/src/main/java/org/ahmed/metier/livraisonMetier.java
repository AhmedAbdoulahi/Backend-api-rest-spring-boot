package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.livraison;
import org.ahmed.entites.societe;

public interface livraisonMetier {
	public livraison save(livraison c); 
	public List<livraison> listLivraison(); 
	public void Supprimer(Long c) ;
	public livraison Ajour(Long id,  livraison a ) ;
}
