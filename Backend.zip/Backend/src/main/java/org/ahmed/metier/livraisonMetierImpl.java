package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.clientRepository;
import org.ahmed.dao.livraisonRepository;
import org.ahmed.entites.livraison;
import org.ahmed.entites.societe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class livraisonMetierImpl implements livraisonMetier {

	@Autowired
	private livraisonRepository repository ;
	@Override
	public livraison save(livraison c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<livraison> listLivraison() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public livraison Ajour(Long id, livraison a) {
		// TODO Auto-generated method stub
		Optional<livraison> c = repository.findById(id) ;
		if(c.isPresent()) {
			livraison l = c.get() ;
			l.setCod_four(a.getCod_four());
			l.setNum_liv(a.getNum_liv());
			l.setDate_liv(a.getDate_liv());
			return repository.save(l) ;
		}
		else {
			return null ;
		}
	}
	

}
