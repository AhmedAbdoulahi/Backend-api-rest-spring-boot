package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.commande;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

public interface commandeMetier {
	public commande save(commande c); 
	public List<commande> listCommande();
	public void Supprimer(Long c) ;
	public commande Ajour(Long id,  commande a ) ;
}
