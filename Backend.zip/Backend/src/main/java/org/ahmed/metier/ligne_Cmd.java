package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.ligne_cmd;
import org.ahmed.entites.societe;

public interface ligne_Cmd {
	public ligne_cmd save(ligne_cmd c); 
	public List<ligne_cmd> listLigne(); 
	public void Supprimer(Long c) ;
	public ligne_cmd Ajour(Long id,  ligne_cmd a ) ;
}
