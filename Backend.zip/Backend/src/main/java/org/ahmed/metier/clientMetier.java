package org.ahmed.metier;

import java.util.List;

import org.ahmed.entites.client;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;


public interface clientMetier {
	public client save(client c); 
	public List<client> listClient(); 
	public void Supprimer(Long c) ;
	public client Ajour(Long id, client a ) ;
}
