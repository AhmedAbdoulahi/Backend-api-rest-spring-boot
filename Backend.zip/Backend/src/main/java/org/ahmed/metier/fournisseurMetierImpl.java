package org.ahmed.metier;

import java.util.List;
import java.util.Optional;

import org.ahmed.dao.fournisseurRepository;
import org.ahmed.entites.fournisseur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class fournisseurMetierImpl implements fournisseurMetier {

	@Autowired
	private fournisseurRepository repository ;
	@Override
	public fournisseur save(fournisseur c) {
		// TODO Auto-generated method stub
		return repository.save(c);
	}

	@Override
	public List<fournisseur> listFournisseur() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void Supprimer(Long c) {
		// TODO Auto-generated method stub
		repository.deleteById(c);
	}

	@Override
	public fournisseur Ajour(Long id, fournisseur a ) {
		
		Optional<fournisseur> c = repository.findById(id) ;
		if(c.isPresent()) {
			fournisseur f = c.get() ;
			f.setNom_four(a.getNom_four());
			f.setTel_four(a.getTel_four());
			f.setVille_four(a.getVille_four());
			return repository.save(f) ;
		}
		else {
			return null ;
		}
	}

}
