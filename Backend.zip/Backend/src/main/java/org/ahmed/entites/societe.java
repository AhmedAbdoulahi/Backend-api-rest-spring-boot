package org.ahmed.entites;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class societe implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id ;
	private String nom_ste ;
	@Column(name = "tel")
	private String tel ;
	@Column(name = "fax")
	private String fax ;
	@Column(name = "ville")
	private String ville ;
	
	@ManyToOne
	@JoinColumn(name="four")
	private fournisseur four ;

	public societe(String nom_ste, String tel, String fax, String ville, fournisseur four) {
		super();
		this.nom_ste = nom_ste;
		this.tel = tel;
		this.fax = fax;
		this.ville = ville;
		this.four = four;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom_ste() {
		return nom_ste;
	}

	public void setNom_ste(String nom_ste) {
		this.nom_ste = nom_ste;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public fournisseur getFour() {
		return four;
	}

	public void setFour(fournisseur four) {
		this.four = four;
	}

	
	
	
	
}
