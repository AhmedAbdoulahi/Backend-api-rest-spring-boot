package org.ahmed.entites;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class article implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) 
	private Long cod_art ;
	private String nom_art ;
	private double pu ;
	private double qte_stock ;
	
	/*@OneToOne(cascade=CascadeType.ALL)
	private ligne_liv lig_liv ;
	
	@OneToOne(cascade=CascadeType.ALL)
	private ligne_cmd lig_cmd ;*/
	
	public article() {
		super();
		// TODO Auto-generated constructor stub
	}
	public article(String nom_art, double pu, double qte_stock) {
		super();
		this.nom_art = nom_art;
		this.pu = pu;
		this.qte_stock = qte_stock;
	}
	public Long getCod_art() {
		return cod_art;
	}
	public void setCod_art(Long cod_art) {
		this.cod_art = cod_art;
	}
	public String getNom_art() {
		return nom_art;
	}
	public void setNom_art(String nom_art) {
		this.nom_art = nom_art;
	}
	public double getPu() {
		return pu;
	}
	public void setPu(double pu) {
		this.pu = pu;
	}
	public double getQte_stock() {
		return qte_stock;
	}
	public void setQte_stock(double qte_stock) {
		this.qte_stock = qte_stock;
	}
	
	
}
