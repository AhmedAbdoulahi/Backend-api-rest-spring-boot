package org.ahmed.entites;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class fournisseur implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) 
	private Long cod_four ;
	private String nom_four ;
	private String ville_four ;
	private String tel_four ;
	
	@JsonIgnore
	@OneToMany(mappedBy="cod",fetch=FetchType.LAZY)
	private Collection<livraison> liv ;
	
	@JsonIgnore
	@OneToMany(mappedBy="four",fetch=FetchType.LAZY)
	private Collection<societe> societe ;
	
	public fournisseur() {
		super();
		// TODO Auto-generated constructor stub
	}
	public fournisseur(String nom_four, String ville_four, String tel_four) {
		super();
		this.nom_four = nom_four;
		this.ville_four = ville_four;
		this.tel_four = tel_four;
	}
	public Long getCod_four() {
		return cod_four;
	}
	public void setCod_four(Long cod_four) {
		this.cod_four = cod_four;
	}
	public String getNom_four() {
		return nom_four;
	}
	public void setNom_four(String nom_four) {
		this.nom_four = nom_four;
	}
	public String getVille_four() {
		return ville_four;
	}
	public void setVille_four(String ville_four) {
		this.ville_four = ville_four;
	}
	public String getTel_four() {
		return tel_four;
	}
	public void setTel_four(String tel_four) {
		this.tel_four = tel_four;
	}
	
	
}
