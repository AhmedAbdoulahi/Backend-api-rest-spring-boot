package org.ahmed.entites;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class ligne_cmd implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) 
	private Long id ;
	@Column(name = "qte_cmd")
	private int qte ;
	
	@ManyToOne
	private commande commande ;
	
	@OneToOne
	private article article ;

	public ligne_cmd(int qte, org.ahmed.entites.commande commande, org.ahmed.entites.article article) {
		super();
		this.qte = qte;
		this.commande = commande;
		this.article = article;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getQte() {
		return qte;
	}

	public void setQte(int qte) {
		this.qte = qte;
	}

	public commande getCommande() {
		return commande;
	}

	public void setCommande(commande commande) {
		this.commande = commande;
	}

	public article getArticle() {
		return article;
	}

	public void setArticle(article article) {
		this.article = article;
	}
	
	
	
	
	
	
}
