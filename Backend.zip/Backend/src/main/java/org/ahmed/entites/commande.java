package org.ahmed.entites;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class commande implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) 
	private Long id ;
	
	@Column(name = "date_cmd")
	private Date dat ;
	
	@ManyToOne
	private client client ;
	
	@JsonIgnore 
	@OneToMany(mappedBy="commande",fetch=FetchType.LAZY)
	private Collection<ligne_cmd> ligne ;

	public commande(Date dateCmd, client cli) {
		super();
		this.dat = dateCmd;
		this.client = cli;
		
	}

	public Long getNum() {
		return id;
	}

	public void setNum(Long num) {
		this.id = num;
	}

	public Date getDateCmd() {
		return dat;
	}

	public void setDateCmd(Date dateCmd) {
		this.dat = dateCmd;
	}

	public client getCli() {
		return client;
	}

	public void setCli(client cli) {
		this.client = cli;
	}

	public Collection<ligne_cmd> getLig_cmd() {
		return ligne;
	}

	public void setLig_cmd(Collection<ligne_cmd> lig_cmd) {
		this.ligne = lig_cmd;
	}
	
	
	
	
}
