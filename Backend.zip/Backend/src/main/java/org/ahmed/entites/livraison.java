package org.ahmed.entites;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class livraison implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) 
	private Long num_liv ;
	private Date date_liv ;
	private Long cod_four ;
	
	@JsonIgnore
	@OneToMany(mappedBy="cod",fetch=FetchType.LAZY)
	private Collection<ligne_liv> lig_liv ;
	
	@ManyToOne
	private fournisseur cod ;
	
	public livraison() {
		super();
		// TODO Auto-generated constructor stub
	}
	public livraison(Date date_liv, Long cod_four) {
		super();
		this.date_liv = date_liv;
		this.cod_four = cod_four;
	}
	public Long getNum_liv() {
		return num_liv;
	}
	public void setNum_liv(Long num_liv) {
		this.num_liv = num_liv;
	}
	public Date getDate_liv() {
		return date_liv;
	}
	public void setDate_liv(Date date_liv) {
		this.date_liv = date_liv;
	}
	public Long getCod_four() {
		return cod_four;
	}
	public void setCod_four(Long cod_four) {
		this.cod_four = cod_four;
	}
	
	
}
