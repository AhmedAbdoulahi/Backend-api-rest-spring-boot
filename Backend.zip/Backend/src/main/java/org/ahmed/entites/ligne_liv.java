package org.ahmed.entites;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class ligne_liv implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long cle ;
	private int qte_liv ;
	@ManyToOne
	private livraison livraison ;
	
	@OneToOne()
	private article article ;
	
	@ManyToOne()
	private livraison cod ;

	public ligne_liv(int qte_liv, org.ahmed.entites.livraison livraison, org.ahmed.entites.article article) {
		super();
		this.qte_liv = qte_liv;
		this.livraison = livraison;
		this.article = article;
	}

	public ligne_liv() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getCle() {
		return cle;
	}

	public void setCle(Long cle) {
		this.cle = cle;
	}

	public int getQte_liv() {
		return qte_liv;
	}

	public void setQte_liv(int qte_liv) {
		this.qte_liv = qte_liv;
	}

	public livraison getLivraison() {
		return livraison;
	}

	public void setLivraison(livraison livraison) {
		this.livraison = livraison;
	}

	public article getArticle() {
		return article;
	}

	public void setArticle(article article) {
		this.article = article;
	}

	public livraison getCod() {
		return cod;
	}

	public void setCod(livraison cod) {
		this.cod = cod;
	}
	
	
}
