package org.ahmed.dao;

import org.ahmed.entites.client; 
import org.springframework.data.jpa.repository.JpaRepository; 
public interface clientRepository extends JpaRepository<client, Long> { 
} 
