package org.ahmed.dao;

import org.ahmed.entites.fournisseur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface fournisseurRepository extends JpaRepository<fournisseur,Long> {

}
