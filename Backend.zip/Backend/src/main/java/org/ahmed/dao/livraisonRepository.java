package org.ahmed.dao;

import org.ahmed.entites.livraison;
import org.springframework.data.jpa.repository.JpaRepository;

public interface livraisonRepository extends JpaRepository<livraison,Long>{

}
