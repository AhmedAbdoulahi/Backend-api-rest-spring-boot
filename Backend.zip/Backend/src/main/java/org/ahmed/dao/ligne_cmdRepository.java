package org.ahmed.dao;

import org.ahmed.entites.ligne_cmd;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ligne_cmdRepository extends JpaRepository<ligne_cmd,Long>{

}
