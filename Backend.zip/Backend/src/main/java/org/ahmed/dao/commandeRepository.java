package org.ahmed.dao;

import org.ahmed.entites.commande;
import org.springframework.data.jpa.repository.JpaRepository;

public interface commandeRepository extends JpaRepository<commande,Long> {

}
