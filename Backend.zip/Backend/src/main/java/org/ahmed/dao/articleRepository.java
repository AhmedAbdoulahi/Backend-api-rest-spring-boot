package org.ahmed.dao;

import org.ahmed.entites.article;
import org.springframework.data.jpa.repository.JpaRepository;

public interface articleRepository extends JpaRepository<article,Long> {

}
