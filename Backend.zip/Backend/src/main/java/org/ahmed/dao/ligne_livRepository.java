package org.ahmed.dao;

import org.ahmed.entites.ligne_liv;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ligne_livRepository extends JpaRepository<ligne_liv,Long>{

}
