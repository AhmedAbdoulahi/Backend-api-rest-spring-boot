package org.ahmed.dao;

import org.ahmed.entites.societe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface societeRepository extends JpaRepository<societe,Long> {

}
